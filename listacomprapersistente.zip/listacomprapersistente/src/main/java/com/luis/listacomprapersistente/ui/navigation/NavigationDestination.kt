package com.luis.listacomprapersistente.ui.navigation

interface NavigationDestination {
    val route: String
    val title: String
}